import sequelize from "./db.js"; /* Conectando meu banco */
import Sequelize,{DataTypes} from "sequelize";

/* No banco sesi crie uma tabela user */
const User = sequelize.define('user',{
   
    id:
    {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
    },

    name:
    {
        type: DataTypes.STRING,
        allowNull: false
    },
    email:
    {
        type: DataTypes.STRING,
        allowNull: false
    },
    password: {
        type: DataTypes.STRING,
        allowNull: false
    },
    cpf: {
        type: DataTypes.STRING,
        allowNull: false
    },
    estado: {
        type: DataTypes.STRING,
        allowNull: false
    },
    cidade: {
        type: DataTypes.STRING,
        allowNull: false
    },
    rua: {
        type: DataTypes.STRING,
        allowNull: false
    },
    cep: {
        type: DataTypes.STRING,
        allowNull: false
    }
    // descricao: {
    //     type: DataTypes.STRING,
    //     allowNull: true
    // }
})

/* User.sync()/* Cria uma tabela caso ela não exista */ 
User.sync({alter:true})

export default User