import express from "express";
import User from "./models/User.js";
import bcrypt from "bcrypt";
import validarToken from "./middlewares/auth.js";
import jwt from "jsonwebtoken";
import cors from "cors";
import multer from "multer";
import Product from "./models/Product.js";
import Pedidos from "./models/Pedidos.js";



const app = express();

const storage = multer.memoryStorage();
const upload = multer({ storage: storage });


// const sequelize = sequelize
app.use(express.json())

app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*") /* Qualquer rota pode ter acesso no momento,  mas quando fizermos o deplay iremos explicar as rotas que poderm ter acesso */
    res.header("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE")/* Definindo metodos de acesso */
    res.header("Access-Control-Allow-Headers", "X-PINGOTHER, Content-Type, Authorization") //permitindo acesso aos conteudos

    app.use(cors())
    next()
})



app.post('/pedido', validarToken, async (req, res) => {
    const dados = { ...req.body, user_id: req.userId };  // Adiciona o user_id ao corpo da requisição

    console.log('Dados recebidos no servidor:', dados); // Log para exibir o objeto do pedido

    try {
        await Pedidos.create(dados);
        return res.json({
            error: false,
            mensagem: "Pedido cadastrado com sucesso"
        });
    } catch (error) {
        console.error('Erro ao cadastrar o pedido no banco de dados:', error);
        return res.json({
            error: true,
            mensagem: "Pedido não cadastrado",
            detalhes: error.message
        });
    }
});


/* pegando nome e email dos usuários que será passado pela tela de login */
app.get('/users', validarToken, async (req, res) => {
    await User.findAll()
        .then((users) => {
            return res.json({
                error: false,
                users
            })
        }).catch(() => {
            return res.json({
                error: true,
                mensagem: "Nenhum usuário foi encotrado"
            })
        })
})

//pegando um usuário especifico  a partir do ID
app.get('/users/:id', validarToken, async (req, res) => {
    const { id } = req.params
    await User.findOne({ where: { id: id } })
        .then((users) => {
            return res.json({
                error: false,
                users,
                mensagem: "Usuário encontrado"
            })
        }).catch(() => {
            return res.json({
                error: true,
                mensagem: "Usuário não foi encontrado"
            })
        })
})


/* Cadastra usuário */
app.post('/user', async (req, res) => {
    var dados = req.body
    dados.password = await bcrypt.hash(dados.password, 8) /* ESSE É O CÓDIGO QUE DEIXAA SENHA CRIPTOGRAF */

    // const {name,email} = req.body
    await User.create(dados)
        .then(() => {
            return res.json({
                error: false,
                mensagem: "Usuário cadastrado com sucesso"
            })
        }).catch(() => {
            return res.json({
                error: true,
                mensagem: "Usuário não cadastrado"
            })
        })
})

/* altera usuário especifico */
app.put('/usuario/:id', validarToken, async (req, res) => {
    const { name, email } = req.body
    const { id } = req.params
    await User.update(req.body, { where: { id: id } })
        .then(() => {
            return res.json({
                error: false,
                mensagem: "Usuário encontrado"
            })
        }).catch(() => {
            return res.json({
                error: true,
                mensagem: "Usuário não encontrado"
            })
        })
})

/* Muda apenas a senha */
app.put('/user-senha/:id', validarToken, async (req, res) => {
    const { id } = req.params
    var dados = req.body
    dados.password = await bcrypt.hash(dados.password, 8)
    await User.update({ password: dados.password }, { where: { id: id } })
        .then(() => {
            return res.json({
                error: false,
                mensagem: "Senha foi trocada por sucesso"
            })
        }).catch(() => {
            return res.json({
                error: true,
                mensagem: "Não foi possivel mudar a senha"
            })
        })
})

/* delete  */
app.delete('/user/:id', validarToken, async (req, res) => {
    const { id } = req.params
    await User.destroy({
        where: {
            id: id
        }
    })
        .then((users) => {
            return res.json({
                error: false,
                users,
                mensagem: "Cadastro deletado"
            })
        }).catch(() => {
            return res.json({
                error: true,
                mensagem: "Usuário não cadastrado"
            })
        })
})

/* Realizar login */
app.post('/user-login', async (req, res) => {
    await tempo(2000)
    function tempo(ms) {
        return new Promise((response) => {
            setTimeout(response, ms)
        })
    }


    var userEmail = await User.findOne({
        where: { email: req.body.email }
    })

    /* Validar o email */
    if (!userEmail) {
        return res.status(400).json({
            error: true,
            mensagem: "Usuário não encontrado"
        })
    }

    /* Validando a senha, comparando senha que o usuário digitopu com */
    if (!(await bcrypt.compare(req.body.password, userEmail.password))) {
        return res.status(400).json({
            error: false,
            mensagem: "senha incorreta"
        })
    }
    /* Assinar com o token */
    const token = jwt.sign({ id: userEmail.id }, process.env.SECRET, {
        expiresIn: "7d" /* chave válida por 7 dias  */
    })

    return res.json({

        error: false,
        mensagem: "Login foi realizado com sucesso",
        token: token

    })
})

app.post('/password-change', validarToken, async (req, res) => {
    const { email, newPassword } = req.body;

    try {
        const user = await User.findOne({ where: { email } });

        if (!user) {
            return res.status(400).json({
                error: true,
                message: "Email não encontrado"
            });
        }

        // Hash da nova senha
        const hashedPassword = await bcrypt.hash(newPassword, 8);

        // Atualiza a senha do usuário no banco de dados
        await User.update({ password: hashedPassword }, { where: { email } });

        // Aguarda 2 segundos antes de responder
        setTimeout(() => {
            res.json({
                error: false,
                message: "Senha redefinida com sucesso"
            });
        }, 2000);
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            error: true,
            message: "Erro ao tentar redefinir a senha. Tente novamente mais tarde."
        });
    }
});

// token parte nova
app.get("/val-token", validarToken, async (req, res) => {

    await User.findByPk(req.userId, { attributes: ['id', 'name', 'email'] })
        .then((user) => {
            return res.json({
                erro: false,
                user
            });

        }).catch(() => {
            return res.status(400).json({
                erro: true,
                mensagem: "Erro: Necessário realizar o login para acessar a página!"

            });

        });
});

app.get('/produtos', async (req, res) => {
    try {
        const products = await Product.findAll();
        return res.json({
            error: false,
            mensagem: "Usuários selecionados com sucesso!",
            products
        });
    } catch (error) {
        return res.status(500).json({
            error: true,
            mensagem: "Erro ao obter usuários"
        });
    }
});


app.get('/produtos/:id', async (req, res) => {
    const { id } = req.params;

    try {
        const product = await Product.findOne({ where: { id: id } });

        if (product) {
            return res.json({
                error: false,
                mensagem: "Produto selecionado com sucesso!",
                product
            });
        } else {
            return res.status(404).json({
                error: true,
                mensagem: "Produto não encontrado"
            });
        }
    } catch (error) {
        return res.status(500).json({
            error: true,
            mensagem: "Erro ao obter o produto"
        });
    }
});

app.get('/produtos/:id/image', async (req, res) => {
    const { id } = req.params;
    try {
        const product = await Product.findByPk(id);
        if (!product) {
            return res.status(404).json({ error: 'Produto não encontrado' });
        }
        res.set('Content-Type', 'image/jpeg'); // Ajuste o tipo conforme necessário
        res.send(product.image);
    } catch (error) {
        res.status(500).json({ error: 'Erro ao buscar imagem' });
    }
});



//Criar Produtos Na Tabela
app.post('/produtos', upload.single('image'), async (req, res) => {
    const { name, price, description, complemento, amount, sold } = req.body;
    const image = req.file ? req.file.buffer : null;

    try {
        await Product.create({ name, price, description, complemento, image, amount, sold });
        return res.json({
            error: false,
            mensagem: "Produto cadastrado com sucesso!"
        });
    } catch (error) {
        console.error(error); // Log do erro para depuração
        return res.status(400).json({
            error: true,
            mensagem: "Produto não cadastrado"
        });
    }
});
//Atualizar Produto
app.put('/produtos/:id', upload.single('image'), async (req, res) => {
    const { id } = req.params;
    const { name, price, description, complemento, amount, sold } = req.body;
    const image = req.file ? req.file.buffer : null;

    try {
        const updatedProduct = await Product.findByPk(id);
        if (!updatedProduct) {
            return res.status(404).json({
                error: true,
                mensagem: "Produto não encontrado"
            });
        }

        await updatedProduct.update({ name, price, description, complemento, image, amount, sold });

        return res.json({
            error: false,
            mensagem: "Produto atualizado com sucesso!"
        });
    } catch (error) {
        console.error(error); // Log do erro para depuração
        return res.status(400).json({
            error: true,
            mensagem: "Não foi possível atualizar o produto"
        });
    }
});


//Delete
app.delete('/produtos/:id', async (req, res) => {
    const { id } = req.params

    await Product.destroy({
        where: {
            id: id
        }
    })
        .then((users) => {
            return res.json({
                error: false,
                mensagem: "Product deletado com sucesso!",
                usuarios_excluidos: users
            })
        }).catch(() => {
            return res.status(400).json({
                error: true,
                mensagem: "Product não Cadastrado",
            })
        })

})





app.listen(8082, () => {
    console.log("Servidor iniciado na porta 8082: ");
})