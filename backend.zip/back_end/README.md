Criar  arquivo package Json
## npm init -y 

Criar gerenciador de API => rotas, urls
## npm install express

Reiniciar Servidor automaticamento
## node --watch app.js

istalando a biblioteca que permite o node se conectar ao banco de dados
## npm install --save sequelize

Definindo o mysql como gerenciador do banco de dados
## npm install --save mysql2

Instalando biblioteca para criptografia de dados
## npm install --save bcrypt

Gerador de chave de token
## npm install --save jsonwebtoken

Gerencia variaveis de ambiente
## npm install dotenv --save

Permite acessar a Api
## npm install --save cors